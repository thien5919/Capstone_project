// src/services/firebase.ts

import firestore from "@react-native-firebase/firestore";
import auth from "@react-native-firebase/auth";
// ⚠️ You must install this: yarn add @react-native-firebase/database
import database, {FirebaseDatabaseTypes} from "@react-native-firebase/database";
import messaging from "@react-native-firebase/messaging";

// 📥 Get user profile
export const getUserProfile = async (uid: string) => {
    const doc = await firestore().collection("users").doc(uid).get();
    return doc.exists ? doc.data() : null;
};

// 💾 Update user profile
export const updateUserProfile = async (uid: string, data: any) => {
    await firestore().collection("users").doc(uid).update(data);
};

// 🧠 Save match preferences
export const saveMatchPreference = async (uid: string, matchPreferences: any) => {
    await updateUserProfile(uid, {matchPreferences});
};

// 💬 Send message to match room
export const sendMessage = async (matchId: string, message: any) => {
    const ref = database().ref(`/messages/${matchId}`).push();
    await ref.set(message);

    // optional: save last message to Firestore for list view
    const participants = matchId.split('_'); // assuming format uid1_uid2
    await firestore().collection('conversations').doc(matchId).set({
        lastMessage: message.text,
        timestamp: message.timestamp,
        participants,
    });
};
// 🔄 Listen for new messages
export const listenForMessages = (
    matchId: string,
    callback: (message: any) => void
) => {
    return database()
        .ref(`/messages/${matchId}`)
        .limitToLast(1)
        .on("child_added", (snapshot) => {
            const msg = snapshot.val();
            callback({ id: snapshot.key, ...msg });
        });
};

// 🔕 Register FCM token
export const registerFcmToken = async () => {
    const fcmToken = await messaging().getToken();
    const user = auth().currentUser;
    if (user && fcmToken) {
        await updateUserProfile(user.uid, {fcmToken});
    }
};

// 🔐 Authentication Services
export const register = async (email: string, password: string) => {
    const result = await auth().createUserWithEmailAndPassword(email, password);
    return result.user;
};

export const login = async (email: string, password: string) => {
    const result = await auth().signInWithEmailAndPassword(email, password);
    return result.user;
};

export const logout = async () => {
    await auth().signOut();
};

export const resetPassword = async (email: string) => {
    await auth().sendPasswordResetEmail(email);
};
