declare module '@env' {
    export const BASE_URL: string;
    export const FCM_SERVER_KEY: string;
  }
  