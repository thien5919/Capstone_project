// src/context/AuthContext.tsx

import React, {createContext, useContext, useEffect, useState} from "react";
import auth from "@react-native-firebase/auth";
import {login, logout, register, resetPassword, getUserProfile} from "../services/firebase";

interface AuthContextType {
    user: any;
    isAuthenticated: boolean;
    login: (email: string, password: string) => Promise<void>;
    register: (email: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
    resetPassword: (email: string) => Promise<void>;
    loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({children}: {children: React.ReactNode}) => {
    const [user, setUser] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = auth().onAuthStateChanged(async (firebaseUser) => {
            if (firebaseUser) {
                const profile = await getUserProfile(firebaseUser.uid);
                setUser({...firebaseUser, ...profile});
            } else {
                setUser(null);
            }
            setLoading(false);
        });
        return unsubscribe;
    }, []);

    const handleLogin = async (email: string, password: string) => {
        const loggedInUser = await login(email, password);
        const profile = await getUserProfile(loggedInUser.uid);
        setUser({...loggedInUser, ...profile});
    };

    const handleRegister = async (email: string, password: string) => {
        const newUser = await register(email, password);
        const profile = await getUserProfile(newUser.uid);
        setUser({...newUser, ...profile});
    };

    const handleLogout = async () => {
        await logout();
        setUser(null);
    };

    const handleResetPassword = async (email: string) => {
        await resetPassword(email);
    };

    return (
        <AuthContext.Provider
            value={{
                user,
                isAuthenticated: !!user,
                login: handleLogin,
                register: handleRegister,
                logout: handleLogout,
                resetPassword: handleResetPassword,
                loading,
            }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
};
