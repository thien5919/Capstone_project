import React, { FC } from "react";
import { View, Text, Button } from "react-native";

const ProfileScreen: FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Profile</Text>
      <Button
  title="Logout"
  onPress={logoutUser}
/>
    </View>
  );
};

export default ProfileScreen;
