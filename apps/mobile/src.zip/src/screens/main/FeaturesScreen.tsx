import React, { FC } from "react";
import { View, Text } from "react-native";

const FeaturesScreen: FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Features!</Text>
    </View>
  );
};

export default FeaturesScreen;
