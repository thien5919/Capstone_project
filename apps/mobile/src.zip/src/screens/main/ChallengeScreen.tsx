import React, { FC } from "react";
import { View, Text } from "react-native";

const ChallengeScreen: FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Challenge!</Text>
    </View>
  );
};

export default ChallengeScreen;
