import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Image } from 'react-native';
import { TextInput, Button, Text } from 'react-native-paper';
import { launchImageLibrary } from 'react-native-image-picker';
import { useNavigation } from '@react-navigation/native';
import { useRegistration } from '../../context/RegistrationContext';

export default function ProfileInfoScreen() {
  const navigation = useNavigation();
  const { updateRegistrationData } = useRegistration();

  const [formData, setFormData] = useState({
    displayName: '',
    age: '',
    gender: '',
    photoUrl: '',
  });

  const [error, setError] = useState<string | null>(null);

  const pickImage = async () => {
    try {
      const result = await launchImageLibrary({ mediaType: 'photo', quality: 1 });
      const uri = result.assets?.[0]?.uri;

      if (uri) {
        setFormData({ ...formData, photoUrl: uri });
      } else {
        setError('No image selected');
      }
    } catch (err) {
      console.error('Error selecting image:', err);
      setError('Failed to select image');
    }
  };

  const handleNext = () => {
    const { displayName, age, gender } = formData;

    if (!displayName || !age || !gender) {
      return setError('Please fill in all required fields.');
    }

    updateRegistrationData({ ...formData, age: parseInt(age, 10) });
    navigation.navigate('MatchPreferences' as never);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.form}>
        {error && <Text style={styles.errorText}>{error}</Text>}

        <TextInput
          label="Display Name"
          value={formData.displayName}
          onChangeText={(text) => setFormData({ ...formData, displayName: text })}
          mode="outlined"
          style={styles.input}
        />

        <TextInput
          label="Age"
          value={formData.age}
          onChangeText={(text) => setFormData({ ...formData, age: text })}
          mode="outlined"
          keyboardType="numeric"
          style={styles.input}
        />

        <TextInput
          label="Gender (e.g. Male / Female / Other)"
          value={formData.gender}
          onChangeText={(text) => setFormData({ ...formData, gender: text })}
          mode="outlined"
          style={styles.input}
        />

        <View style={styles.imageContainer}>
          {formData.photoUrl ? (
            <Image source={{ uri: formData.photoUrl }} style={styles.image} />
          ) : (
            <View style={styles.placeholderImage}>
              <Text>No image selected</Text>
            </View>
          )}
          <Button mode="outlined" onPress={pickImage} style={styles.imageButton}>
            Choose Photo
          </Button>
        </View>

        <Button mode="contained" onPress={handleNext} style={styles.button}>
          Next
        </Button>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  form: {
    padding: 16,
  },
  input: {
    marginBottom: 12,
    backgroundColor: '#fff',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 12,
  },
  placeholderImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: '#e5e7eb',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  imageButton: {
    marginTop: 8,
  },
  button: {
    marginTop: 24,
    backgroundColor: '#6366f1',
    paddingVertical: 8,
  },
  errorText: {
    color: '#ef4444',
    marginBottom: 12,
    textAlign: 'center',
  },
});
