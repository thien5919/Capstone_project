const { messaging } = require('../firebase');

exports.sendNotification = async (toToken, title, body) => {
  const message = {
    token: toToken,
    notification: {
      title,
      body,
    },
    android: { priority: 'high' },
    apns: { payload: { aps: { sound: 'default' } } },
  };

  return await messaging.send(message);
};
