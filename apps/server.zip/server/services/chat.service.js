const admin = require('firebase-admin');
const { sendNotification } = require('./fcm.service');
const { saveNotification } = require('./notification.service');

const sendMessage = async (roomId, message) => {
    const timestamp = Date.now();
  
    const messageData = {
      senderId: message.senderId,
      text: message.text,
      timestamp,
    };

    await admin.database().ref(`chats/${roomId}/messages`).push(messageData);
    await admin
      .firestore()
      .collection('chatRooms')
      .doc(roomId)
      .collection('messages')
      .add({
        ...messageData,
        sentAt: new Date(timestamp),
      });
  
    const recipientId = extractRecipientFromRoomId(roomId, message.senderId);
    const userDoc = await admin.firestore().collection('users').doc(recipientId).get();
    const fcmToken = userDoc.data()?.fcmToken;
  
    if (fcmToken) {
      const title = '💬 New Message';
      const body = `${message.text.substring(0, 60)}...`;
  
      await sendNotification(fcmToken, title, body);
  
      await saveNotification(recipientId, { title, body });
    }
  
    return messageData;
  };
  


const getChatHistory = async (roomId, limit = 50) => {
  const snapshot = await admin
    .firestore()
    .collection('chatRooms')
    .doc(roomId)
    .collection('messages')
    .orderBy('sentAt', 'desc')
    .limit(limit)
    .get();

  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

module.exports = {
  sendMessage,
  getChatHistory,
};
