const express = require('express');
const router = express.Router();
const { sendMessage, getChatHistory } = require('../services/chat.service');
const authMiddleware = require('../middlewares/auth.middleware');

// Bắt buộc xác thực cho mọi route
router.use(authMiddleware);

// POST /api/chat/send/:roomId
router.post('/send/:roomId', async (req, res) => {
  try {
    const roomId = req.params.roomId;
    const message = {
      senderId: req.uid,
      text: req.body.text,
    };
    const sentMessage = await sendMessage(roomId, message);
    res.status(200).json(sentMessage);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/chat/history/:roomId
router.get('/history/:roomId', async (req, res) => {
  try {
    const roomId = req.params.roomId;
    const history = await getChatHistory(roomId);
    res.status(200).json(history);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
